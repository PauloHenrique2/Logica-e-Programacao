﻿namespace AtividadeProduto
{
    partial class FrmDescontao
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtVlrproduto = new System.Windows.Forms.TextBox();
            this.lblProduto = new System.Windows.Forms.Label();
            this.btnDesconto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtVlrproduto
            // 
            this.txtVlrproduto.Location = new System.Drawing.Point(56, 61);
            this.txtVlrproduto.Name = "txtVlrproduto";
            this.txtVlrproduto.Size = new System.Drawing.Size(100, 20);
            this.txtVlrproduto.TabIndex = 0;
            // 
            // lblProduto
            // 
            this.lblProduto.AutoSize = true;
            this.lblProduto.Location = new System.Drawing.Point(53, 36);
            this.lblProduto.Name = "lblProduto";
            this.lblProduto.Size = new System.Drawing.Size(123, 13);
            this.lblProduto.TabIndex = 1;
            this.lblProduto.Text = "Digite o valor do produto";
            // 
            // btnDesconto
            // 
            this.btnDesconto.Location = new System.Drawing.Point(56, 98);
            this.btnDesconto.Name = "btnDesconto";
            this.btnDesconto.Size = new System.Drawing.Size(114, 23);
            this.btnDesconto.TabIndex = 2;
            this.btnDesconto.Text = "Calcular Desconto";
            this.btnDesconto.UseVisualStyleBackColor = true;
            this.btnDesconto.Click += new System.EventHandler(this.btnDesconto_Click);
            // 
            // FrmDescontao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDesconto);
            this.Controls.Add(this.lblProduto);
            this.Controls.Add(this.txtVlrproduto);
            this.Name = "FrmDescontao";
            this.Text = "AppDescontão";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtVlrproduto;
        private System.Windows.Forms.Label lblProduto;
        private System.Windows.Forms.Button btnDesconto;
    }
}

