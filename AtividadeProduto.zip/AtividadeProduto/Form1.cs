﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeProduto
{
    public partial class FrmDescontao : Form
    {
        public FrmDescontao()
        {
            InitializeComponent();
        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            float vlrProduto = float.Parse(txtVlrproduto.Text);
            float resultado;

            resultado = vlrProduto - (vlrProduto * 0.10f);
            MessageBox.Show(" O valor com desconto é " + resultado);
        }
    }
}
