﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturandoDados
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

        private void FrmDados_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Abriu Formulário!");
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou na label inteiro!");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Texto Inteiro alterado!");
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou em enviar!");
            
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tudo limpo!");
        }
    }
}
